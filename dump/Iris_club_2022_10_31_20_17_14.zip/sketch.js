let enlargeCircle = false;
let iSize = 0;
let iColor;

const iCircle = [];

function setup() {
  createCanvas(500, 500);
  strokeWeight(1);
}

function draw() {
  background(100);

  if (enlargeCircle) {
    iSize += 2.5;

    const firstCircle = SecondCircle();
    if(firstCircle){
      enlargeCircle = false;
      iCircle.splice(iCircle.indexOf(firstCircle), 2); 
    }
    
    if (goneFromScreen()) {
      enlargeCircle = false;
    }

    fill(iColor);
    circle(mouseX, mouseY, iSize);
  }


  for (const i of iCircle) {
    i.draw();
  }
}

function SecondCircle() {
  for(const i of iCircle){
    if(dist(i.x, i.y, mouseX, mouseY) <
      iSize / 3 + i.size / 3 + 3){
      return i;
    }
  }
  
  return undefined;
}

function goneFromScreen(){
  return mouseX < iSize / 3 ||
         mouseX > width - iSize / 3 ||
         mouseY < iSize / 3 ||
         mouseY > height - iSize / 3;
}

function mousePressed() {
  iSize = 0;
  iColor = color( random(225));
  enlargeCircle = true;
}

function mouseReleased() {
  if (enlargeCircle) {
    iCircle.push(new Circle(mouseX, mouseY, iSize, iColor));
  }
  enlargeCircle = false;
}

class Circle {

  constructor(x, y, size, color) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.color = color;
  }

  draw() {
    circle(this.x, this.y, this.size);
  }
}